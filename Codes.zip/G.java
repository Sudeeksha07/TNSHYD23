package com.day2;


import com.day2.*;

public class G extends F{
	public static void main(String args[]) {
		G obj = new G();
		obj.display();
	}
}
