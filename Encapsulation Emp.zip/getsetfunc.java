package com.employee;
	

public class getsetfunc {
		private String employee;
		private int salary;
		private String project;
		
		public String getEmployee() {
			return employee;
		}
		public void setEmployee(String employee) {
			this.employee = employee;
		}
		public int getSalary() {
			return salary;
		}
		public void setSalary(int salary) {
			this.salary = salary;
		}
		public String getProject() {
			return project;
		}
		public void setProject(String project) {
			this.project = project;
		}
		public String section() {
			
			 if(salary>=50000 && salary<100000) {
			      return "Manager";
			    } 
			 else if(salary>=30000 && salary<50000) {
			      return "Developer";
			    }
			 else {
			      return "Intern";
			
		}

	}

}
