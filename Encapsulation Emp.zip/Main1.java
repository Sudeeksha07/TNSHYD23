package com.employee;

public class Main1 {
	public static void main(String args[]) {
		Encap1 obj = new Encap1();
		obj.salary=25000;
		System.out.println(obj.salary);
	}

}
