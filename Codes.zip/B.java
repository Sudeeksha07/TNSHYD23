package com.day2;

public class B {
	int b=50;
	static int c=150;
	int display() 
	{
		return 10;
		}
	static void display1()
	{
		System.out.println(10);
	}
	public static void main(String args[]) {
	B obj=new B();
	System.out.println(obj.b);
	obj.display();
	System.out.println(B.c);
	B.display1();
	}
	}
