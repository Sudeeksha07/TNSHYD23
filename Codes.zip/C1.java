package com.day2;

public class C1 {
	public static void main(String args[]) {
		C obj = new C();
		obj.display();
		System.out.println(obj.a);
		System.out.println(C.c);
		C.display1();
	}

}


