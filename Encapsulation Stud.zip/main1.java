package com.encapsulation;

public class main1 {
	public static void main(String args[]) {
		Encap1 obj = new Encap1();
		obj.age=21;
		System.out.println(obj.age);
	}

}
