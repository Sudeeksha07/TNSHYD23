package com.encapsulation;

public class main2getset {
	public static void main(String args[]) {
		Encapgetset obj = new Encapgetset();
		obj.setAge(21);
		System.out.println(obj.getAge());
	

	    obj.setName("Sudeeksha");
	    System.out.println(obj.getName());
}
}
