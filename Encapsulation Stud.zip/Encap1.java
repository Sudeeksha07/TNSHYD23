package com.encapsulation;

public class Encap1 {
	
	private String name;
	public int age;
	
}
