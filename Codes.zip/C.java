package com.day2;

public class C {
	int a=50;
	static int c=150;
	int display() {
		return 10;
		}
	static void display1() {
		System.out.println(20);
	}

}
