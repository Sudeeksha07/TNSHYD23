package com.day2;
class E {
	 void display() {
		 System.out.println("DEFAULT");
	 }
	 public static void main(String args[]) {
		 E obj=new E();
		 obj.display();
		 
	 }

}




