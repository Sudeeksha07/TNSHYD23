package com.employee;

public class main2getset {
	public static void main(String args[]) {
		 Encapgetset obj = new  Encapgetset();
		 obj.setEmployee("S");
		 System.out.println(obj.getEmployee());
		 obj.setSalary(25000);
		 System.out.println(obj.getSalary());
		 obj.setProject("S/w");
		 System.out.println(obj.getProject());
	}
	

}
