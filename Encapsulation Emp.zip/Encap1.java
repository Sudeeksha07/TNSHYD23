package com.employee;

public class Encap1 {
	private String emp;
	public int salary;
	private String project;

}
