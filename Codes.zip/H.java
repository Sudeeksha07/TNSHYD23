package com.day2;
public class H {
	public void display() {
		System.out.println("Public");
	}

public static void main(String args[]) {
	H obj = new H();
	obj.display();
}
}


