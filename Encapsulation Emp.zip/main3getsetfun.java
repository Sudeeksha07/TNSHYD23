package com.employee;

public class main3getsetfun {
	public static void main(String args[]) {
		 getsetfunc obj = new getsetfunc();
		 obj.setEmployee("S");
		 obj.setSalary(5000);
		 obj.setProject("S/w");
		 System.out.println(obj.section());
	}
}

