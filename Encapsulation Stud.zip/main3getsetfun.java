package com.encapsulation;

public class main3getsetfun {
	public static void main(String args[]) {
	 getsetfun obj = new getsetfun();
	 obj.setAge (21);
	 obj.setName ("Sudeeksha");
	 obj.setAddress("Hyd");
	 System.out.println(obj.elgible());
	

	}
}


