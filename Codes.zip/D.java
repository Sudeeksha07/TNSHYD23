package com.day2;


class D {
	 private void display()
	 {
		 System.out.println("Private");
	 }
	public static void main(String args[]) {
		D obj=new D();
		obj.display();
	}

}

