package com.day2;
public class F {
	protected void display() {
		System.out.println("PROTECTED");
	}
}
